function nome(isaac){
    console.log(isaac);
}