let lista = [1,"fone",true,"celular", 2];
    lista.push("fulano", "ciclano");
console.log(lista);