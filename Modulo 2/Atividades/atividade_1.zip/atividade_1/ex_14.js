let lista = [1,"fone",true,"celular", 2];
    lista.splice(2,4, "estou sendo add", "45");
console.log(lista);