function triplo(num){

    return num * 3;
}
console.log(triplo(10)); 

