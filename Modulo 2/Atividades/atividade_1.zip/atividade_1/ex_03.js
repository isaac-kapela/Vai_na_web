function mensagem(){
    console.log("Hello word");
}