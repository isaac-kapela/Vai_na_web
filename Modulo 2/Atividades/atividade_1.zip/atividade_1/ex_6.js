function entreterimento(filme,MusicaFavorita){
    console.log("filme:" + filme);
    console.log("Música Favorita: " + MusicaFavorita);
}

entreterimento("O incrivel caso de benjamin botton","freudian");