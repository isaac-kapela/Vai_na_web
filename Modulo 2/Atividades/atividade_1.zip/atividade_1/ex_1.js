let dia = "dia";

if(dia == "dia"){
    console.log("claro!");
}
else{
    console.log("está de noite!");
}