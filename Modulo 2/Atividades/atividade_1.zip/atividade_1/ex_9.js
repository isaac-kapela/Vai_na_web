let lista = [1,"fone",true,"celular", 2];
    lista.unshift("elemento adicionado no inicio da lista")
console.log(lista);