let lista = [1,"fone",true,"celular", 2];
    lista.pop();
console.log(lista);