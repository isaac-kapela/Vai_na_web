function pessoa(nome,idade, estiloMusical){
    console.log("Nome:",nome);
    console.log("idsde:",idade);
    console.log("estilo Musical",estiloMusical);
}

pessoa("Isaac",18,"Rap");