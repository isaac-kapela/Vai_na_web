let numeros = [7, 5, 6, 3, 8, 9, 2, 1, 4];
numeros.sort(function(a, b) {
    return a - b;
});
console.log(numeros); 
